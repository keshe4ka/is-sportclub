# is_sportclub
